package fundamental01;

import java.util.Date;

import org.json.JSONObject;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class HelloWorld {
	public static void main(String[] args) {
		
		System.out.println();
	}
	
	
	/**
     * ���� jwt token
     * @return
     */
//    public static String generateToken(){
////    	JSONObject jsonO = new JSONObject();
////        jsonO.put("", "");
//    	String jsonStr = "{\"name\":\"zp\",\"id\":\"xw\"}";
//    	String secret="123456wtegtey";
//    	for(int i=1;i<266;i++){
//    		secret+=i;
//    	}
//    	System.out.println(secret);
//        String token = Jwts.builder()
//        		     
//                .setSubject()// ������
//                //.claim("id","121") // ����
//                .setIssuedAt(new Date()) // ����ʱ��
//                .setExpiration(new Date(System.currentTimeMillis() + expired))
//                .signWith(SignatureAlgorithm.HS256,secret) // ǩ������ �� ��Կ
//                .compressWith(CompressionCodecs.DEFLATE)// ���غɽ���ѹ��
//                .compact(); // ѹ��һ��
//        return token;
//    }

}



