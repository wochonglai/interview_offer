package fundamental01;

import io.jsonwebtoken.Claims;
//import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

//import java.awt.RenderingHints.Key;
import java.util.Date;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

/**
 * jwt������
 */
public class JwtUtils {
    /**
     * ʵ��
     */
    private static JwtUtils instance;

    /**
     * ������
     */
    private String subObject = "owner";

    /**
     * ����ʱ�䣬Ĭ��7��
     */
    private long expired = 1000 * 60 * 60 * 24 * 7;

    /**
     * jwt����
     */
    private static JwtBuilder jwtBuilder;

    /**
     * ��Կ
     */
    private String secret = "secret";// ��Կ

    /**
     * ��ȡʵ��
     * @return
     */
    public static JwtUtils getInstance(){
        if (instance == null){
            instance = new JwtUtils();
        }
        jwtBuilder = Jwts.builder();
        return instance;
    }

    /**
     * ������Ϣ(ͨ����һ��User��Ϣ��������һЩ������Ԫ����)
     * @param key
     * @param val
     * @return
     */
    public JwtUtils setClaim(String key,Object val){
        jwtBuilder.claim(key,val);
        return this;
    }

    /**
     * ���� jwt token
     * @return
     */
    public String generateToken(){
    	for(int i=1;i<14;i++){
    		secret+="abc";
    	}
    	System.out.println(secret);
    	SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
    	//We will sign our JWT with our ApiKey secret
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secret);
        System.out.println(secret);
        SecretKeySpec signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());
        String token = jwtBuilder
                .setSubject(subObject) // ������
                .claim("id","121") // ����
                .setIssuedAt(new Date()) // ����ʱ��
                .setExpiration(new Date(System.currentTimeMillis() + expired))
                .signWith(SignatureAlgorithm.HS256,secret) // ǩ������ �� ��Կ
//                .compressWith(CompressionCodecs.DEFLATE)// ���غɽ���ѹ��
                .compact(); // ѹ��һ��
    
        return token;
    }

    /**
     * ���� token
     * @param token
     * @return
     */
    public Claims check(String token){
        try{
            final Claims claims = Jwts.parser()
                    .setSigningKey(DatatypeConverter.parseBase64Binary(secret))
                    .parseClaimsJws(token)
                    .getBody();
            return claims;
        }catch (Exception e){}
        return null;
    }

    public String getSubObject() {
        return subObject;
    }

    /**
     * ���÷�����
     * @param subObject
     * @return
     */
    public JwtUtils setSubObject(String subObject) {
        this.subObject = subObject;
        return this;
    }

    public long getExpired() {
        return expired;
    }

    /**
     * ���ù���ʱ��
     * @param expired
     * @return
     */
    public JwtUtils setExpired(long expired) {
        this.expired = expired;
        return this;
    }

    public String getSecret() {
        return secret;
    }

    /**
     * ������Կ
     * @param secret
     * @return
     */
    public JwtUtils setSecret(String secret) {
        this.secret = secret;
        return this;
    }
    public static void main(String[] args) {
        JwtUtils jwt = JwtUtils.getInstance();
        String token = jwt
                .setClaim("id",789)
                .setClaim("name","xiaochi")
                .setExpired(50000)
                .generateToken();
        System.out.println(token);

        System.out.println("-----------------------");

//        String s = "eyJhbGciOiJIUzI1NiJ9.eyJpZCI6Nzg5LCJuYW1lIjoieGlhb2NoaSIsInN1YiI6Im93bmVyIiwiaWF0IjoxNTgxNzc0MjE4LCJleHAiOjE1ODE3NzQyNjh9.VLWsIJUrG6VD1nbxgbvEmAu5dLCtpb0r1ToYdmilcAQ";
        Claims claims = jwt.check(token);
        if (claims != null){
            Integer id = (Integer)claims.get("id");
            String name = (String) claims.get("name");
            System.out.println(id);
            System.out.println(name);
        }else {
            System.out.println("�Ƿ�token");
        }
}
}